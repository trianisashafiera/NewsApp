package com.example.newsapp;

import com.example.newsapp.models.NewsHeadlines;

public interface SelectListener {
    void OnNewsClicked(NewsHeadlines headlines);
}
