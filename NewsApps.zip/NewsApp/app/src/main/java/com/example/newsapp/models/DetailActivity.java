package com.example.newsapp.models;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.newsapp.R;

public class DetailActivity extends AppCompatActivity {
    NewsHeadlines headlines;
    TextView txt_title,txt_author,txt_time,txt_detail, txt_content;
    ImageView img_news;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        txt_title = findViewById(R.id.text_detail_title);
        txt_author = findViewById(R.id.author_detail);
        txt_time = findViewById(R.id.time_detail);
        txt_detail = findViewById(R.id.detail_detail);
        txt_content = findViewById(R.id.detail_content);
        img_news = findViewById(R.id.img_detail);
        headlines = (NewsHeadlines) getIntent().getSerializableExtra("data");

        txt_title.setText(headlines.getTitle());
        txt_author.setText(headlines.getAuthor());
        txt_time.setText(headlines.getPublishedAt());
        txt_detail.setText(headlines.getDescription());
        txt_content.setText(headlines.getContent());


    }
}
